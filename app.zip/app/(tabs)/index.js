import React, { useEffect, useRef, useState } from 'react';
import { BackHandler, StatusBar, StyleSheet, useColorScheme, View } from 'react-native';
import { WebView } from 'react-native-webview';

export default function App() {
  const isDarkMode = useColorScheme() === 'dark';
  const webViewRef = useRef(null);
  const [canGoBack, setCanGoBack] = useState(false);

  useEffect(() => {
    const onBackPress = () => {
      if (canGoBack && webViewRef.current) {
        webViewRef.current.goBack();
        return true; // prevent closing the app
      }
      return false; // allow closing the app
    };

    const backHandler = BackHandler.addEventListener('hardwareBackPress', onBackPress);
    return () => backHandler.remove();
  }, [canGoBack]);

  return (
    <View style={styles.container}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      <WebView
        ref={webViewRef}
        source={{ uri: 'https://bharathkusuma-a6449.web.app' }}
        style={{ flex: 1 }}
        onNavigationStateChange={(navState) => {
          setCanGoBack(navState.canGoBack);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
